$(document).ready(function () {
  $.fn.popup.defaults.pagecontainer = '#wrapper'
});