<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
// $conn = new mysqli('localhost', 'root', '', 'u892124399_mithra');

$conn =new mysqli('localhost','u892124399_mithra','9a]wc7Y1A','u892124399_mithra');


if ($conn->connect_error) {

    echo "error to MYSQL(".$conn->error.")".($conn->error);
    echo "changes done";
} else{
    //  echo "done connected";
}
?>

